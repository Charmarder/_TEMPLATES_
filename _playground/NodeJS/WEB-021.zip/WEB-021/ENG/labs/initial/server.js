var express = require('express');
var app = express();
var path = require('path');
app.use(express.static(path.join(__dirname, '../dist/notes-app')));
var session = require('express-session');
var bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
var Db = require('mongodb').Db;
var Server = require('mongodb').Server;
var db = new Db('tutor',
  new Server("localhost", 27017, {safe: true},
    {auto_reconnect: true}, {}));

db.open(function(err){
  if (err) console.log(err);
  else console.log("mongo db is opened!");
  db.collection('notes', function(error, notes) {
    db.notes = notes;
  });

});

app.use(session({
  secret: 'angular_tutorial',
  resave: true,
  saveUninitialized: true,
  cookie: {
    secure: false,
    httpOnly: false
  },

}));

var notes_init = [
  {text: "First note"},
  {text: "Second note"},
  {text: "Third note"}
];
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.get("/notes", function(req,res) {
  db.notes.find(req.query).toArray(function(err, items) {
    res.send(items);
  });
});
app.post("/notes", function(req,res) {
  db.notes.insert(req.body).then(function() {
    res.end();
  });
});
var ObjectID = require('mongodb').ObjectID;
app.delete("/notes", function(req,res) {
  var id = new ObjectID(req.query.id);
  db.notes.remove({_id: id}, function(err){
    if (err) {
      console.error(err);
      res.send({ok:false});
    } else {
      res.send({ok:true});
    }
  });
});


app.listen(8080);

/*

FOLDER STRUCTURE:

root
  app
  server
     server.js
	 package.json
  index.html
  package.json

*/
